#ifndef DP_H
#define DP_H

#include "caverna.h"

int encontrarMelhorCaminho(Caverna* caverna, int caminho[][2]);

#endif